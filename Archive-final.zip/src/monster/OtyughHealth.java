package monster;

/**
 * Enum for Otyugh health.
 */
public enum OtyughHealth {
  healthy, injured, dead
}
