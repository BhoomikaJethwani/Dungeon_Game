package dungeon;

/**
 * Enum for Location Type.
 */
public enum LocationType {
  Cave, Tunnel
}
